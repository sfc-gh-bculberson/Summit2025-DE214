Snowflake Python Ingest Service SDK 
===================================


.. image:: http://img.shields.io/:license-Apache%202-brightgreen.svg
    :target: http://www.apache.org/licenses/LICENSE-2.0.txt

.. image:: https://travis-ci.org/snowflakedb/snowflake-ingest-python.svg?branch=master
    :target: https://travis-ci.org/snowflakedb/snowflake-ingest-python

.. image:: https://codecov.io/gh/snowflakedb/snowflake-ingest-python/branch/master/graph/badge.svg
    :target: https://codecov.io/gh/snowflakedb/snowflake-ingest-python

.. image:: https://badge.fury.io/py/snowflake-ingest.svg
    :target: https://pypi.python.org/pypi/snowflake-ingest

The Snowflake Ingest Service SDK allows users to ingest files into their Snowflake data warehouse in a programmatic
fashion via key-pair authentication, or stream the data into Snowflake via the Rowset API .

Prerequisites
=============

Python 3.4+
-----------
The Snowflake Ingest SDK requires Python 3.4 or above. Backwards compatibility with older versions of Python 3
or any versions of Python 2 is not planned at this time.


A 2048-bit RSA key pair
-----------------------
Snowflake Authentication for the Ingest Service requires creating a 2048 bit
RSA key pair and, registering the public key with Snowflake. For detailed instructions,
please visit the relevant `Snowflake Documentation Page <https://docs.snowflake.com/en/user-guide/authentication.html>`_.


Furl, PyJWT, Requests, and Cryptography
---------------------------------------

Internally, the Snowflake Ingest SDK makes use of `Furl <https://github.com/gruns/furl>`_, 
`PyJWT <https://github.com/jpadilla/pyjwt>`_, and `Requests <https://github.com/psf/requests>`_.
In addition, the `cryptography <https://github.com/pyca/cryptography>`_ is used with PyJWT to sign JWT tokens.


Installation
============ 
If you would like to use this sdk, you can install it using python setuptools.

.. code-block:: bash

    pip install snowflake-ingest


Example
=====
Check out the example for Rowset API streaming_ingest_example.py, which performs the following operations:

1. Reads a JSON file that contains details regarding the Snowflake Account, User and Private Key. Refer to :code:`profile.json.example` for more details. `Here <https://docs.snowflake.com/en/user-guide/key-pair-auth.html#configuring-key-pair-authentication>`_  are the steps required to generate a private key.
2.  Creates a :code:`SnowflakeStreamingIngestClient` which can be used to open one or more Streaming Channels pointing to the same or different pipes.
3.  Creates a :code:`SnowflakeStreamingIngestChannel` against a Database, Schema, and Pipe. Please note: The database, schema, table, and pipe are expected to be present before opening the Channel. Example SQL queries to create them:

.. code-block:: sql
    :linenos: 11

    CREATE OR REPLACE DATABASE my_database;
    CREATE OR REPLACE SCHEMA my_schema;
    CREATE OR REPLACE TABLE my_table(data variant, c1 number, c2 string);
    CREATE OR REPLACE PIPE my_pipe
    AS
        COPY INTO MY_TABLE FROM (
            SELECT $1, GET($1, 'c1'), GET_IGNORE_CASE($1, 'c2') FROM TABLE(
                DATA_SOURCE(
                TYPE => 'STREAMING_ROWSET'
            )
    ));

4. Inserts 1000 rows in 5 batches into the channel created in step 3 using the :code:`insert_rows` API on the Channel object. :code:`insert_rows` API also takes in an optional :code:`offset_token` String, which can be associated with this batch of rows.
5. Closes the channel, which will also ensure everything is committed to Snowflake.


Contributing to this repo
=========================
Each PR must pass all required github action merge gates before approval and merge. This repo use
`ruff <https://docs.astral.sh/ruff/>`_ as linter and formatter. Run ruff linter over the project via :code:`ruff check`,
run ruff formatter via :code:`ruff format`. Check
`./.ruff.toml <https://github.com/snowflakedb/streaming-rowset-api-python/blob/master/.ruff.toml>`_ for details on lint
rules.