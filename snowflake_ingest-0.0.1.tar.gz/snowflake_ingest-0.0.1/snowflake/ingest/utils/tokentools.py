# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.

"""
tokentools.py - provides services for automatically creating and renewing
JWT tokens for authenticating to Snowflake
"""

import base64
import hashlib
from datetime import datetime, timedelta
from logging import getLogger

import jwt
from apscheduler.schedulers.background import BackgroundScheduler
from cryptography.exceptions import UnsupportedAlgorithm
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
    load_pem_private_key,
)

from snowflake.connector.util_text import parse_account
from snowflake.ingest.utils.error import IngestClientError
from snowflake.ingest.utils.network import RequestHandler

logger = getLogger(__name__)

ISSUER = "iss"
EXPIRE_TIME = "exp"
ISSUE_TIME = "iat"
SUBJECT = "sub"


class JWTTokenManager:
    """
    Given a private key, username, and account, signs and creates tokens for use in Snowflake Ingest Requests
    """

    LIFETIME = timedelta(minutes=59)  # The tokens will have a 59 minute lifetime
    RENEWAL_DELTA = timedelta(minutes=54)  # Tokens will be renewed after 54 minutes
    ALGORITHM = "RS256"  # Tokens will be generated using RSA with SHA256

    def __init__(
        self,
        account: str,
        user: str,
        private_key: str,
        lifetime: timedelta = LIFETIME,
        renewal_delay: timedelta = RENEWAL_DELTA,
    ):
        """
        __init__ creates a jwt token manager with the specified context arguments
        :param account: the account in which data is being loaded
        :param user: The user who is loading these files
        :param private_key: the private key we'll use for signing tokens
        :param lifetime: how long this key will live (in minutes)
        :param renewal_delay: how long until the jwt token manager should renew the key
        """

        logger.info(
            """Creating JWT token Manager with arguments
            account : %s, user : %s, lifetime : %s, renewal_delay : %s""",
            account,
            user,
            lifetime,
            renewal_delay,
        )

        # Snowflake account names are canonically in all caps. Also trim account names if contain '.'
        self.account = parse_account(account.upper())
        self.user = user.upper()  # Snowflake user names are also in all caps by default
        self.qualified_username = self.account + "." + self.user  # Generate the full user name
        self.lifetime = lifetime  # the timedelta until our tokens expire
        self.renewal_delay = renewal_delay  # the timedelta until we renew the token
        self.private_key = private_key  # stash the private key
        self.renew_time = datetime.utcnow()  # We need to renew the token NOW
        self.token = None  # We initially have no token

    def get_token(self) -> str:
        """
        Regenerates the current token if and only if we have exceeded the renewal time
        bounds set
        :return: the new token
        """
        now = datetime.utcnow()  # Fetch the current time

        # If the token has expired, or doesn't exist, regenerate it
        if self.token is None or self.renew_time <= now:
            logger.info(
                "Renewing token because renewal time (%s) is eclipsed by present time (%s)",
                self.renew_time,
                now,
            )
            # Calculate the next time we need to renew the token
            self.renew_time = now + self.renewal_delay

            public_key_fp = self.calculate_public_key_fingerprint(self.private_key)

            # Create our payload
            payload = {
                # The issuer is the public key fingerprint
                ISSUER: self.qualified_username + "." + public_key_fp,
                # subject is user's fully qualified username
                SUBJECT: self.qualified_username,
                # The payload was issued at this point it time
                ISSUE_TIME: now,
                # The token should no longer be accepted after our lifetime has elapsed
                EXPIRE_TIME: now + JWTTokenManager.LIFETIME,
            }

            # Regenerate the actual token
            self.token = jwt.encode(payload, self.private_key, algorithm=JWTTokenManager.ALGORITHM)
            logger.info("New Token created")

        return self.token.decode("utf-8") if isinstance(self.token, bytes) else self.token

    def calculate_public_key_fingerprint(self, private_key: str) -> str:
        """
        Given a private key in pem format, return the public key fingerprint
        :param private_key: private key string
        :return: public key fingerprint
        """
        try:
            private_key = load_pem_private_key(private_key.encode(), None, default_backend())
        except (ValueError, UnsupportedAlgorithm) as e:
            raise IngestClientError.INVALID_PRIVATE_KEY() from e

        # get the raw bytes of public key
        public_key_raw = private_key.public_key().public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)

        # take sha256 on raw bytes and then do base64 encode
        sha256hash = hashlib.sha256()
        sha256hash.update(public_key_raw)

        public_key_fp = "SHA256:" + base64.b64encode(sha256hash.digest()).decode("utf-8")
        logger.info("Public key fingerprint is %s", public_key_fp)

        return public_key_fp

    def get_account(self) -> str:
        return self.account

    @staticmethod
    def get_token_type() -> str:
        """
        :return: return the authorization type of the token
        """
        return "KEYPAIR_JWT"


class ScopedTokenManager:
    """
    This is used for managing the streaming ingest rowset API scoped token for rowset requests.
    We periodically refresh the rowset scoped token in the background job through the snowflake service use
    the jwt token from the given JWTTokenManager.
    """

    def __init__(
        self,
        jwt_manager: JWTTokenManager,
        refresh_request_handler: RequestHandler,
        client_request_handler: RequestHandler,
        rowset_hostname: str,
        renewal_delay: timedelta = JWTTokenManager.RENEWAL_DELTA,
    ):
        """
        :param jwt_manager: the JWTTokenManager used to exchange/refresh the scoped token for the rowset service
        :param refresh_request_handler: the request handler used to send the refresh token request
        :param client_request_handler: the request handler used to send the client request to the snowflake service
                with the scoped token
        :param rowset_hostname: the rowset hostname for the scoped token
        :param renewal_delay: how long until the scoped_token_manager should renew the scoped token
        """
        logger.info(
            """Creating Scoped Token Manager with arguments
            account : %s, user : %s, renewal_delay : %s""",
            jwt_manager.account,
            jwt_manager.user,
            renewal_delay,
        )

        self._token = None
        self.rowset_hostname = rowset_hostname
        self._jwt_manager = jwt_manager
        self._refresh_request_handler = refresh_request_handler
        self._client_request_handler = client_request_handler

        # Did we fail to refresh our token at some point (in the background job)
        self._refresh_failed = False

        # refresh to retrieve the first token
        self.refresh_token()

        # schedule the background service to run the job to refresh the scoped token
        self._scheduler = BackgroundScheduler()
        self._scheduler.add_job(self.refresh_token, "interval", seconds=renewal_delay.total_seconds())
        self._scheduler.start()

    def refresh_token(self) -> None:
        """
        refresh the current scoped token
        """

        try:
            self._token = self._refresh_request_handler.refresh_scoped_token(
                self.rowset_hostname, self._jwt_manager.get_token()
            )
            self._client_request_handler.set_scoped_token(self._token, None)
        except Exception as e:
            # log the info since the refresh might be in the background job
            logger.info(f"Fail to refresh rowset scoped token, host={self.rowset_hostname}, error message = {e!s}")
            self._refresh_failed = True
            self._client_request_handler.set_scoped_token(self._token, e)
            raise e

    def close(self):
        """
        close the scoped token manager and shut down all the resources it holds (the refresh scheduling service)
        """
        self._scheduler.shutdown()

    @staticmethod
    def get_token_type() -> str:
        """
        :return: return the authorization type of the token
        """
        return "OAUTH"
