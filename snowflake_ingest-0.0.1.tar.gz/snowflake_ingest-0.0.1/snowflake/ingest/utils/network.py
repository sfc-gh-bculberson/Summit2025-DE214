# Copyright (c) 2012-2024 Snowflake Computing Inc. All rights reserved.
import threading

# import python connector to inject ocsp check method into requests library
import time
from logging import getLogger
from typing import Any, Dict, Optional, Union

import requests
from requests import Response

from snowflake.connector.constants import HTTP_HEADER_CONTENT_TYPE
from snowflake.ingest.utils.error import IngestClientError, IngestResponseError
from snowflake.ingest.utils.uris import URLGenerator

logger = getLogger(__name__)

# default timeout in seconds for a rest request
DEFAULT_REQUEST_TIMEOUT = 1 * 60

# keys in the http
SF_HEADER_AUTHORIZATION_TOKEN_TYPE = "X-Snowflake-Authorization-Token-Type"  # noqa: S105
AUTHORIZATION = "Authorization"
GRANT_TYPE = "grant_type"

# constant values in the http
JSON_CONTENT_TYPE = "application/json"
URL_ENCODED_CONTENT_TYPE = "application/x-www-form-urlencoded"
TOKEN_EXCHANGE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:jwt-bearer"  # noqa: S105
SCOPE = "scope"

# the string name for the HTTP auth bearer
BEARER_PARAMETER = "Bearer "


class RequestHandler:
    """
    The class to hold all make http requests to the Snowflake service from streaming ingest service
    """

    def __init__(self, url_generator: URLGenerator, token_type: str, token: Optional[str] = None) -> None:
        self._lock = threading.Lock()
        self._url_generator = url_generator
        self._token_type = token_type
        self._token = token
        self._refresh_exception = None

    def open_channel(
        self,
        channel_name: str,
        db_name: str,
        schema_name: str,
        pipe_name: str,
        offset_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """make the open_channel request to Snowflake Service

        Parameters:
            channel_name (str): The name of the channel.
            db_name (str): The name of the database.
            schema_name (str): The name of the schema.
            pipe_name (str): The name of the pipe.
            offset_token (Optional[str]): The offset where the stream was ingested last.
        """
        payload = {"offset_token": offset_token}
        url = self._url_generator.make_open_channel_url(db_name, schema_name, pipe_name, channel_name)
        try:
            response = SnowflakeRestful.put(url, payload, self._make_request_header(self._token, self._token_type))
            if "continuation_token" not in response or not response["continuation_token"]:
                raise IngestClientError.OPEN_CHANNEL_FAILURE_ON_HTTP(
                    "Internal Error, please contact Snowflake support."
                )
            return response
        except IngestResponseError as e:
            raise IngestClientError.OPEN_CHANNEL_FAILURE_ON_HTTP(e.message) from None

    def insert_rows(
        self,
        channel_name: str,
        db_name: str,
        schema_name: str,
        pipe_name: str,
        rows: str,
        continuation_token: str,
        offset_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """make the insert rows request to Snowflake Service
        Parameters:
            :param channel_name: the channel to insert the rows
            :param db_name: the database to insert the rows
            :param schema_name: the schema to insert the rows
            :param pipe_name: the pipe to insert the rows
            :param rows: the data to be sent to insert
            :param continuation_token: the continuation token of the channel to insert the rows
            :param offset_token: the offset of the rows
        """
        url = self._url_generator.make_insert_rows_url(
            db_name, schema_name, pipe_name, channel_name, continuation_token, offset_token=offset_token
        )
        try:
            response = SnowflakeRestful.post(url, self._make_request_header(self._token, self._token_type), data=rows)
            if "next_continuation_token" not in response or not response["next_continuation_token"]:
                raise IngestClientError.INSERT_ROWS_FAILURE_ON_HTTP("Internal Error, please contact Snowflake support.")
            return response
        except IngestResponseError as e:
            raise IngestClientError.INSERT_ROWS_FAILURE_ON_HTTP(e.message) from None

    def get_channel_status(
        self,
        channel_name: str,
        db_name: str,
        schema_name: str,
        pipe_name: str,
    ) -> Dict[str, str]:
        """make the get the channel status request to Snowflake Service

        Parameters:
            :param channel_name: the channel to get the latest committed token
            :param db_name: the database to get the latest committed token
            :param schema_name: the schema to get the latest committed token
            :param pipe_name: the pipe to get the latest committed token
        """
        url = self._url_generator.make_get_channel_status_url(db_name, schema_name, pipe_name, channel_name)
        try:
            response = SnowflakeRestful.get(url, self._make_request_header(self._token, self._token_type))
            if "offset_token" not in response:
                raise IngestClientError.GET_COMMITTED_TOKEN_FAILURE_ON_HTTP(
                    "Internal Error, please contact Snowflake support."
                )
            return response
        except IngestResponseError as e:
            raise IngestClientError.GET_COMMITTED_TOKEN_FAILURE_ON_HTTP(e.message) from None

    def get_host_name(self) -> str:
        """
        construct and send the request to get the customer's rowset api service hostname through the snowflake service
        :return: the customer's rowset api service hostname
        """
        url = self._url_generator.make_get_rowset_host_name_url()
        try:
            response = SnowflakeRestful.get(
                url, self._make_request_header(self._token, self._token_type), text_response=True
            )
            if not response:
                raise IngestClientError.GET_ROWSET_HOSTNAME_FAILED("Internal Error, please contact Snowflake support.")
            return response
        except IngestResponseError as e:
            logger.debug(
                f"Fail to get rowset host, current host={self._url_generator.host}, error message = {e.message}"
            )
            raise IngestClientError.GET_ROWSET_HOSTNAME_FAILED(e.message) from None

    def refresh_scoped_token(self, rowset_hostname: str, token: str) -> str:
        """
        construct and send the request to refresh the rowset api scoped token with customer's provided token
        :param rowset_hostname: the customer's rowset hostname
        :param token: the customer provided token
        :return: the scoped rowset token
        """
        url = self._url_generator.make_scoped_token_url()
        try:
            headers = self._make_request_header(token, self._token_type, content_type=URL_ENCODED_CONTENT_TYPE)
            data = {GRANT_TYPE: TOKEN_EXCHANGE_GRANT_TYPE, SCOPE: rowset_hostname.lower()}
            response = SnowflakeRestful.post(url, headers, data=data, text_response=True)
            if not response:
                raise IngestClientError.REFRESH_SCOPED_TOKEN_FAILED(
                    self._url_generator.host, "Internal Error, please contact Snowflake support"
                )
            return response
        except IngestResponseError as e:
            raise IngestClientError.REFRESH_SCOPED_TOKEN_FAILED(self._url_generator.host, e.message) from None

    def set_scoped_token(self, scoped_token: str, e: Exception) -> None:
        """
        set the new scoped authorization token for the request

        Parameters:
            scoped_token (str): the new scoped token to send the request
            e (Exception): the exception that occurred when refreshing the token
        """
        with self._lock:
            self._token = scoped_token
            self._refresh_exception = e

    def get_scoped_token(self) -> str:
        """
        get the new scoped authorization token for the request
        """
        with self._lock:
            if self._refresh_exception:
                raise self._refresh_exception

            if self._token is None:
                raise IngestClientError.REFRESH_SCOPED_TOKEN_FAILED(
                    self._url_generator.host, "Scoped token is None. Request can not proceed"
                )

            return self._token

    @staticmethod
    def _make_request_header(token: str, token_type: str, content_type: str = JSON_CONTENT_TYPE) -> Dict[str, str]:
        """
        Create the dict for the http request header.

        Args:
            token (str): the authorization token for the request
            token_type (str): the authorization token type
            content_type(str, optional): the content type for the request

        Returns:
            the dict representing the http headers
        """
        return {
            HTTP_HEADER_CONTENT_TYPE: content_type,
            SF_HEADER_AUTHORIZATION_TOKEN_TYPE: token_type,
            AUTHORIZATION: BEARER_PARAMETER + token,
        }


class SnowflakeRestful:
    """
    A simple wrapper over python request library to handle retry
    """

    @classmethod
    def post(
        cls,
        url: str,
        headers: Dict,
        json: Optional[Dict] = None,
        data: Optional[Union[Dict, str]] = None,
        text_response: bool = False,
    ) -> Union[str, Dict[str, Any]]:
        """
        Http POST request
        :param text_response: whether the http response content is in text format. Default format is json
        :param url: request url,
        :param json: post request body in json
        :param data: post request body in data
        :param headers: request headers, authentication etc
        :return: response payload.
        """
        return cls._exec_request_with_retry(
            url=url, method="POST", json=json, data=data, headers=headers, text_response=text_response
        )

    @classmethod
    def put(cls, url: str, json: Dict, headers: Dict) -> Dict[str, Any]:
        """
        Http PUT request
        :param url: request url,
        :param json: post request body
        :param headers: request headers, authentication etc
        :return: response payload.
        """
        return cls._exec_request_with_retry(url=url, method="PUT", json=json, headers=headers)

    @classmethod
    def get(cls, url: str, headers: Dict, text_response: bool = False) -> Union[str, Dict[str, Any]]:
        """
        Http GET request
        :param text_response: whether the http response content is in text format. Default format is json
        :param url: request url,
        :param headers: request headers, authentication etc
        :return:
        """
        return cls._exec_request_with_retry(url=url, method="GET", headers=headers, text_response=text_response)

    @classmethod
    def _exec_request_with_retry(
        cls,
        url: str,
        method: str,
        headers: Optional[Dict] = None,
        json: Optional[Dict] = None,
        text_response: bool = False,
        data: Optional[Dict] = None,
    ) -> Union[str, Dict[str, Any]]:
        # TODO SNOW-1852817: use standard retry library for http retries
        class RetryCtx:
            def __init__(self, timeout=None):
                self.retry_count = 0
                self.total_timeout = timeout
                self.next_sleep_time = 1
                self._request_start_time = time.time()

            def sleep_time(self):
                """
                :return: time in seconds to sleep next time, -1 if should not sleep
                """
                if time.time() - self._request_start_time > self.total_timeout:
                    logger.info("Request timeout reached.")
                    return -1
                # exponential backoff
                this_sleep_time = self.next_sleep_time
                self.next_sleep_time = this_sleep_time * 2
                self.retry_count += 1
                logger.info(
                    "Retried request. Backoff time %d, Retry count %d",
                    this_sleep_time,
                    self.retry_count,
                )
                return this_sleep_time

        retry_context = RetryCtx(DEFAULT_REQUEST_TIMEOUT)

        while True:
            response = cls._exec_request(url=url, method=method, headers=headers, json=json, data=data)

            if response.ok:
                if text_response:
                    return response.text
                return response.json()
            if cls._can_retry(response.status_code):
                next_sleep_time = retry_context.sleep_time()
                if next_sleep_time > 0:
                    time.sleep(next_sleep_time)
                    continue
            raise IngestResponseError(response)

    @staticmethod
    def _exec_request(
        url: str,
        method: str,
        headers: Optional[Dict] = None,
        json: Optional[Dict] = None,
        data: Optional[Dict] = None,
    ) -> Response:
        return requests.request(
            method=method, url=url, headers=headers, json=json, data=data, timeout=DEFAULT_REQUEST_TIMEOUT
        )

    @staticmethod
    def _can_retry(http_code):
        # retry on timeout, too many requests, and server error
        # 408: Request Timeout
        # 429: Too Many Requests
        # 5xx: Server Error
        return http_code == 408 or http_code == 429 or 500 <= http_code < 600
