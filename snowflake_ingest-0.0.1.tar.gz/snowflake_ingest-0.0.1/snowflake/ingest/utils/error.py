# Copyright (c) 2024 Snowflake Computing Inc. All rights reserved.

from __future__ import annotations

from typing import Any

from requests import Response


class IngestResponseError(Exception):
    """Error thrown when an ingest request failed.

    The IngestResponseError exception is raised when an ingest request is failed. This initializer parsed failed ingest
    response or streaming ingest response to generate an ingest response error.
    """

    def __init__(self, response: Response):
        self.http_error_code = response.status_code

        try:
            json_body = response.json()
        except ValueError:
            self.message = f"Http Error: {self.http_error_code}, Message: {response.reason}"
            return

        self.code = json_body["code"] if "code" in json_body else json_body["status_code"]
        self.success = json_body.get("success", None)
        self.data = json_body.get("data", None)
        self._raw_message = json_body["message"]

        self.message = f"Http Error: {self.http_error_code}, Vender Code: {self.code}, Message: {self._raw_message}"

        return

    def __str__(self):
        return self.message


class IngestClientError(Exception):
    """Error thrown in the ingest client side.

    This IngestClientError exception is raised when an error occurs in an ingest client. Use the error static methods to
    generate corresponding error.
    """

    def __init__(self, error_code: str, error_message: str):
        super().__init__(error_message)
        self._error_code = error_code
        self._message = error_message

    def __repr__(self):
        return f"{self.__class__.__name__}({self._message!r}, {self._error_code!r})"

    def __str__(self):
        return f"[Error{self._error_code}]: {self._message}"

    def __eq__(self, other):
        return isinstance(other, IngestClientError) and self._error_code == other._error_code

    @property
    def error_code(self) -> str:
        return self._error_code

    @staticmethod
    def INTERNAL_ERROR(message: str) -> IngestClientError:
        return IngestClientError("0001", f"Internal Error: {message}.")

    @staticmethod
    def NULL_VALUE(key: str) -> IngestClientError:
        return IngestClientError("0002", f"Required value is null, Key: {key}.")

    @staticmethod
    def NULL_OR_EMPTY_STRING(key: str) -> IngestClientError:
        return IngestClientError("0003", f"Required value is empty, Key: {key}.")

    @staticmethod
    def INCORRECT_TYPE(key: str, value: Any, *types: type) -> IngestClientError:
        return IngestClientError("0004", f"Incorrect type {type(value)}, {key} should be one of {types}")

    @staticmethod
    def MISSING_CONFIG(key: str) -> IngestClientError:
        return IngestClientError("005", f"Missing {key} in config file.")

    @staticmethod
    def CLOSED_CLIENT() -> IngestClientError:
        return IngestClientError("006", "Client is closed, please recreate to restart.")

    @staticmethod
    def INVALID_PRIVATE_KEY() -> IngestClientError:
        return IngestClientError(
            "007",
            "Invalid private key, private key should be a valid PEM RSA private key.",
        )

    @staticmethod
    def OPEN_CHANNEL_FAILURE_ON_HTTP(raw_message: str) -> IngestClientError:
        return IngestClientError(
            "008",
            f"Open channel failure {raw_message}",
        )

    @staticmethod
    def GET_ROWSET_HOSTNAME_FAILED(raw_message: str) -> IngestClientError:
        return IngestClientError(
            "009",
            f"Fail to get rowset hostname {raw_message}",
        )

    @staticmethod
    def REFRESH_SCOPED_TOKEN_FAILED(host: str, raw_message: str) -> IngestClientError:
        return IngestClientError(
            "010",
            f"Fail to refresh rowset scoped token, host={host}, error message = {raw_message}",
        )

    @staticmethod
    def INVALID_CHANNEL() -> IngestClientError:
        return IngestClientError("011", "Channel is invalid, please recreate the channel first.")

    @staticmethod
    def INSERT_ROWS_FAILURE_ON_HTTP(raw_message: str) -> IngestClientError:
        return IngestClientError(
            "012",
            f"insert rows failure {raw_message}",
        )

    @staticmethod
    def CLOSED_CHANNEL() -> IngestClientError:
        return IngestClientError("013", "Channel is closed, please recreate to restart.")

    @staticmethod
    def CHANNELS_WITH_UNCOMMITTED_ROWS(channel: str) -> IngestClientError:
        return IngestClientError(
            "014",
            f"{channel} might contain uncommitted rows due to server "
            f"side errors, please consider reopening the channels to replay the data "
            f"loading by using the latest persistent offset token.",
        )

    @staticmethod
    def GET_COMMITTED_TOKEN_FAILURE_ON_HTTP(raw_message: str) -> IngestClientError:
        return IngestClientError(
            "015",
            f"get committed token failed: {raw_message}",
        )

    @staticmethod
    def INVALID_DATA_FORMAT(message: str) -> IngestClientError:
        return IngestClientError(
            "016",
            f"invalid row format: {message}",
        )
