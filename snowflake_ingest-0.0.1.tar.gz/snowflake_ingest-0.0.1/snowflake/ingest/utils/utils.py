# Copyright (c) 2024 Snowflake Computing Inc. All rights reserved.
import logging
from typing import Any, Optional

import orjson

from snowflake.ingest.utils import IngestClientError

_logger = logging.getLogger(__name__)


class Utils:
    """Contains Ingest related utility functions."""

    @staticmethod
    def assert_not_null(name: str, value: object) -> None:
        if value is None:
            raise IngestClientError.NULL_VALUE(name)

    @staticmethod
    def assert_string_not_null_or_empty(name: str, value: str) -> None:
        if value is None or len(value) == 0:
            raise IngestClientError.NULL_OR_EMPTY_STRING(name)

    @staticmethod
    def assert_at_least_one_string_not_null_or_empty(name: str, *values: Optional[str]) -> None:
        join_str = "".join([v for v in values if v is not None])
        if join_str == "":
            raise IngestClientError.NULL_OR_EMPTY_STRING(name)

    @staticmethod
    def assert_types(name: str, value: Any, *types: type) -> None:
        for _type in types:
            if isinstance(value, _type):
                return
        raise IngestClientError.INCORRECT_TYPE(name, value, *types)

    @staticmethod
    def validate_json_format(rows: str) -> None:
        """
        Check whether the input string is a valid newline delimited JSON format for streaming ingestion.

        This function validates that each line in the input string is a valid JSON object. It skips empty lines or lines
        containing only whitespace. If a line is not a valid JSON object, it raises an IngestClientError with an
        appropriate error message.

        :param rows: The rows to check whether it is in the valid newline delimited JSON format.
        :raises IngestClientError: If a line is not a valid JSON object or if JSON parsing fails.
        """
        try:
            for line in rows.splitlines():
                if (not line) or line.isspace():
                    continue
                # each line should be a single dict object
                line_json = orjson.loads(line)
                if not isinstance(line_json, dict):
                    raise IngestClientError.INVALID_DATA_FORMAT(
                        f"expected a single json object in the line, but got {type(line_json)}."
                    )
        except orjson.JSONDecodeError as e:
            raise IngestClientError.INVALID_DATA_FORMAT(e.msg) from e
