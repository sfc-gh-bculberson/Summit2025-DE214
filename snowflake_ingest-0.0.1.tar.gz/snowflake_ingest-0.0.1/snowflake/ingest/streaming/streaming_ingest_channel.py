# Copyright (c) 2024 Snowflake Computing Inc. All rights reserved.

import logging
import time
from typing import Optional

from snowflake.ingest.utils import IngestClientError, Utils

_logger = logging.getLogger(__name__)

COMMIT_MAX_NO_COMMIT_PROGRESS_RETRY_COUNT = 60
COMMIT_RETRY_INTERVAL_IN_SECONDS = 1


class SnowflakeStreamingIngestChannel:
    """Implementation of the Streaming Ingest Channel.

    A logical partition that represents a connection to a single Snowflake pipe, data will be ingested into the
    channel, and then flushed to Snowflake table periodically through pipe in the background.

    Channels are identified by their name and only one channel with the same name may ingest data
    at the same time. When a new channel is opened, all previously opened channels with the same name
    are invalidated (this applies for the pipe globally. not just in a single JVM). In order to
    ingest data from multiple threads/clients/applications, we recommend opening multiple channels,
    each with a different name.
    """

    def __init__(
        self,
        name: str,
        db_name: str,
        schema_name: str,
        pipe_name: str,
        continuation_token: str,
        owning_client: object,
    ) -> None:
        """Create a new Streaming Ingest Channel.

        Parameters:
            name (str): The name of the channel
            db_name (str): The database name for the channel
            schema_name (str): The schema name for the channel
            pipe_name (str): The pipe name for the channel
            continuation_token (str): The continuation_token of the channel to send the insertRows requests
            owning_client (object): the SnowflakeStreamingIngestClient owns the channel
        """

        from snowflake.ingest.streaming.streaming_ingest_client import SnowflakeStreamingIngestClient

        if not isinstance(owning_client, SnowflakeStreamingIngestClient):
            raise IngestClientError.INCORRECT_TYPE("owning_client", owning_client, SnowflakeStreamingIngestClient)

        self._name = name
        self._db_name = db_name
        self._schema_name = schema_name
        self._pipe_name = pipe_name
        self._continuation_token = continuation_token
        self._owning_client = owning_client
        self._is_valid = True
        self._is_closed = False
        self._latest_offset_token = None
        self._fully_qualified_name = f"{self._db_name}.{self._schema_name}.{self._pipe_name}.{self._name}"

    def get_fully_qualified_name(self) -> str:
        """
        Get the fully qualified channel name, in the format of dbName.schemaName.pipeName.channelName
        """
        return self._fully_qualified_name

    def get_name(self) -> str:
        """
        Get the name of the channel
        """
        return self._name

    def get_db_name(self) -> str:
        """
        Get the name of the channel
        """
        return self._db_name

    def get_schema_name(self) -> str:
        """
        Get the database name of the channel
        """
        return self._schema_name

    def get_owner_entity_name(self) -> str:
        """
        Get the name of the owner based on the ownership of the channel (the pipe)
        """
        return self._pipe_name

    def get_fully_qualified_entity_name(self) -> str:
        """
        Get the fully qualified owner name that the channel belongs to (the pipe)
        """
        return f"{self._db_name}.{self._schema_name}.{self._pipe_name}"

    def is_valid(self) -> bool:
        """
        :return: whether the channel is in the valid stage to accept requests
        """
        return self._is_valid

    def _invalidate(self) -> None:
        """
        Mark the channel as invalid
        """
        self._is_valid = False

    def insert_rows(self, rows: str, offset_token: Optional[str] = None):
        """
        Insert a batch of rows into the channel, each row is represented using newline delimited json
        with String where the keys of each row in json are the column names and the values row are the column
        values of the rows

        :param rows: the data to insert into the pipe
        :param offset_token: the offset token for the rows. It is used for replay in case of failures. It could be null
                            if you do not plan on replaying or can't reply
        """
        # check whether we are in a valid stage to send the insert row requests
        self._check_validation()

        if self.is_closed():
            raise IngestClientError.CLOSED_CHANNEL()

        # valid the row format
        Utils.assert_string_not_null_or_empty("rows", rows)
        Utils.validate_json_format(rows)

        # send the insert rows
        try:
            response = self._owning_client._send_insert_rows_request(
                self._name,
                self._db_name,
                self._schema_name,
                self._pipe_name,
                rows,
                self._continuation_token,
                offset_token=offset_token,
            )
            self._latest_offset_token = offset_token
            self._continuation_token = response["next_continuation_token"]
        except Exception as e:
            self._invalidate()
            raise e

    def get_latest_committed_offset_token(self) -> str:
        """
        Get the latest committed offset token of the channel from Snowflake
        """
        # check whether we are in a valid stage to send the get status
        self._check_validation()

        # send the get channel status
        try:
            response = self._owning_client.send_get_channel_status_request(
                self._name, self._db_name, self._schema_name, self._pipe_name
            )
            return response["offset_token"]
        except Exception as e:
            self._invalidate()
            raise e

    def close(self):
        """
        Close the channel, this function will make sure all the data in this channel is committed
        if the offset token is provided in the insert rows
        """
        if self.is_closed():
            return

        self._check_validation()

        # if the customer does not provide the offset token during the insert rows, we would just close the channle
        if self._latest_offset_token is None:
            self._is_closed = True
            return

        if not self._verify_data_fully_committed():
            # we still have rows not committed, throw exceptions
            raise IngestClientError.CHANNELS_WITH_UNCOMMITTED_ROWS(self.get_fully_qualified_name())

        # the channel is fully committed and we mark it as closed
        self._is_closed = True

    def is_closed(self) -> bool:
        """
        :return: whether the channel is closed
        """
        return self._is_closed

    def _check_validation(self) -> None:
        """
        Check whether the channel is still valid and whether the client is still open to perform requests.
        If not, the corresponding exception would be thrown
        """
        if self._owning_client.is_closed():
            raise IngestClientError.CLOSED_CLIENT()

        if not self.is_valid():
            raise IngestClientError.INVALID_CHANNEL()

    def _verify_data_fully_committed(
        self, max_retries=COMMIT_MAX_NO_COMMIT_PROGRESS_RETRY_COUNT, retry_interval=COMMIT_RETRY_INTERVAL_IN_SECONDS
    ) -> bool:
        """
        Check if any channels has uncommitted rows after our commit retry logic: if there are channels
        that are not fully committed, we would perform a series of retries with an interval of
        COMMIT_RETRY_INTERVAL_IN_MS as long as there are commit in process for any of the channels on
        the server side or the server side does not make progress on commit after COMMIT_MAX_RETRY_COUNT of retries.

        :return: whether this channel is fully committed after the retries
        """

        retry = 0
        previous_committed_token = None

        while retry < max_retries:
            current_committed_token = self.get_latest_committed_offset_token()

            # if the committed token matches with the latest offset token sent from the insert rows,
            # the channel is fully committed
            if self._latest_offset_token == current_committed_token:
                return True

            # not fully committed
            if previous_committed_token == current_committed_token:
                # the server side is not making progress on the commit, increase the count here
                retry += 1
            else:
                # the server side is making progress on the commit
                previous_committed_token = current_committed_token
                retry = 0

            time.sleep(retry_interval)

        # the channel is not committed after retries
        return False
