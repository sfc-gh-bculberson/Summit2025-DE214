# Copyright (c) 2024 Snowflake Computing Inc. All rights reserved.

import logging
from typing import Any, Dict, Optional, Tuple, Union

from snowflake.ingest.streaming.streaming_ingest_channel import SnowflakeStreamingIngestChannel
from snowflake.ingest.utils import IngestClientError, JWTTokenManager, URLGenerator, Utils
from snowflake.ingest.utils.network import RequestHandler
from snowflake.ingest.utils.tokentools import ScopedTokenManager
from snowflake.ingest.utils.uris import DEFAULT_HOST_FMT

_logger = logging.getLogger(__name__)

# Default configs, tuple of default variable and accepted types
DEFAULT_CONFIG: Dict[str, Tuple[Any, Union[type, Tuple[type, ...]]]] = {
    "user": (None, str),
    "account": (None, str),
    "private_key": (None, str),
    "host": (None, (type(None), str)),
    "port": (443, (int, str)),
    "scheme": ("https", str),
}


class SnowflakeStreamingIngestClient:
    """Implementation of the Streaming Ingest Client.

    This is the starting point for using the Streaming Ingest Client APIs, a single client maps to exactly one
    account in Snowflake; however, multiple clients can point to the same account. Each client will contain
    information for Snowflake authentication and authorization.
    """

    def __init__(
        self,
        name: str,
        **kwargs,
    ) -> None:
        """Create a new Streaming Ingest Client.

        Parameters:
        name (str): The name of the Streaming Ingest Client.

        Keyword Args:
            user (str): The username of the Snowflake account.
            account (str): Account name used to authenticate with Snowflake.
            private_key (str): The private key used to authenticate with Snowflake.
            host (str): The hostname of the Snowflake account. Default to "`account`.snowflakecomputing.com".
            port (int): The port to communicate with the host. Default to 443.
            scheme (str): The scheme used to communicate with the host. Default to "https".
        """
        self._name = name
        self._is_closed = False

        for key, (value, type_) in DEFAULT_CONFIG.items():
            value = kwargs.get(key, value)
            try:
                Utils.assert_types(key, value, type_)
            except IngestClientError as e:
                if value is None:
                    raise IngestClientError.MISSING_CONFIG(key) from None
                # rethrow the original exception
                raise e
            setattr(self, f"_{key}", value)

        if not self._host:
            self._host = DEFAULT_HOST_FMT.format(self._account)

        self._dev_test_mode = kwargs.get("ROWSET_DEV_VM_TEST_MODE", "True").lower() != "False".lower()

        jwt_token_manager = JWTTokenManager(self._account, self._user, self._private_key)
        url_generator = URLGenerator(self._host, self._scheme, int(self._port))
        jwt_request_handler = RequestHandler(
            url_generator, JWTTokenManager.get_token_type(), jwt_token_manager.get_token()
        )
        if self._dev_test_mode:
            self._token_manager = jwt_token_manager
            self._request_handler = jwt_request_handler
        else:
            # get the customer's rowset specific hostname
            hostname = jwt_request_handler.get_host_name()
            # create the customer request handler and rowset scoped _token manager
            rowset_url_generator = URLGenerator(hostname, url_generator.scheme, url_generator.port)
            self._request_handler = RequestHandler(rowset_url_generator, ScopedTokenManager.get_token_type())
            self._token_manager = ScopedTokenManager(
                jwt_token_manager, jwt_request_handler, self._request_handler, hostname
            )

        _logger.info("Rowset client created, name=%s, account=%s", self._name, self._account)

    def open_channel(
        self,
        channel_name: str,
        db_name: str,
        schema_name: str,
        pipe_name: str,
        offset_token: Optional[str] = None,
    ) -> SnowflakeStreamingIngestChannel:
        """Open a channel to a pipe or a table in the Snowflake database.

        Parameters:
            channel_name (str): The name of the channel.
            db_name (str): The name of the database.
            schema_name (str): The name of the schema.
            pipe_name (str): The name of the pipe.
            offset_token (Optional[str]): The offset where the stream was ingested last.
        """
        Utils.assert_string_not_null_or_empty("channel_name", channel_name)
        Utils.assert_string_not_null_or_empty("db_name", db_name)
        Utils.assert_string_not_null_or_empty("schema_name", schema_name)
        Utils.assert_string_not_null_or_empty("pipe_name", pipe_name)

        if self._is_closed:
            raise IngestClientError.CLOSED_CLIENT()
        _logger.debug(f"Open channel request start, channel={channel_name}, pipe={db_name}.{schema_name}.{pipe_name}")

        response = self._request_handler.open_channel(channel_name, db_name, schema_name, pipe_name, offset_token)

        return SnowflakeStreamingIngestChannel(
            channel_name, db_name, schema_name, pipe_name, response["continuation_token"], self
        )

    def close(self) -> None:
        """
        close the client and shut down all the resources it holds
        """
        if self._is_closed:
            pass

        if not self._dev_test_mode:
            # shutdown the refresh service
            self._token_manager.close()
        self._is_closed = True

    def is_closed(self) -> bool:
        """whether the client is closed or not"""
        return self._is_closed

    def _send_insert_rows_request(
        self,
        channel_name: str,
        db_name: str,
        schema_name: str,
        pipe_name: str,
        rows: str,
        continuation_token: str,
        offset_token: str = Optional[None],
    ) -> Dict[str, Any]:
        """send an insert rows request to the Snowflake Service to ingest the data
        This method should only be called from SnowflakeStreamingIngestChannel

        Parameters:
            :param channel_name: the channel to insert the rows
            :param db_name: the database to insert the rows
            :param schema_name: the schema to insert the rows
            :param pipe_name: the pipe to insert the rows
            :param rows: the data to be sent to insert
            :param offset_token: the offset of the rows
            :param continuation_token: the continuation token of the channel to insert the rows
            :return: insert row results in the dict format
        """
        return self._request_handler.insert_rows(
            channel_name, db_name, schema_name, pipe_name, rows, continuation_token, offset_token=offset_token
        )

    def send_get_channel_status_request(
        self,
        channel_name: str,
        db_name: str,
        schema_name: str,
        pipe_name: str,
    ) -> Dict[str, str]:
        """send request to get the channel status to the snowflake service

        Parameters:
            :param channel_name: the channel to get the channel status
            :param db_name: the database to get the channel status
            :param schema_name: the schema to get the channel status
            :param pipe_name: the pipe to get the channel status
            :return: a dict representation the current channel status
        """
        return self._request_handler.get_channel_status(channel_name, db_name, schema_name, pipe_name)
